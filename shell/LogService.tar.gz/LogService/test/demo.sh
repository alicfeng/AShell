#!/usr/bin/env bash

simple=(1122_aaaa 2233_nnnn 3344_jjj)
for item in ${simple[*]}
do
    mkdir ../log/${item} && date >> ../log/${item}/vas.INFO
done

