#!/usr/bin/env bash

simple=(1122_6789_aaaa 2234_7868_nnnn 3344_7688_jjyj)
for item in ${simple[*]}
do
    mkdir ../../log/${item} && date >> ../../log/${item}/vas.INFO
done

